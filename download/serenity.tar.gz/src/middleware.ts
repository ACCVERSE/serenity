import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  // For landing page, no auth required - just pass through
  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|api|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)',
  ],
}
